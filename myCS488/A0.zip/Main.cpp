#include "A0.hpp"

int main( int argc, char **argv ) 
{
	CS488Window::launch( argc, argv, new A0(), 1024, 768, "Assignment 0" );
	return 0;
}
